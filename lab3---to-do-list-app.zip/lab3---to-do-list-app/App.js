import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet } from "react-native";

export default function App() {
  const [text, setText] = useState("");
  const [tasks, setTasks] = useState([]);

  const addTask = () => {
    if (text.trim() !== "") {
      setTasks([...tasks, { id: Math.random().toString(), title: text, done: false }]);
      setText("");
    }
  };

  const toggleTask = (id) => {
    setTasks(
      tasks.map((task) =>
        task.id === id ? { ...task, done: !task.done } : task
      )
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>🌸 My To-Do List 🌸</Text>

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Enter a task..."
          placeholderTextColor="#c7b7e3"
          value={text}
          onChangeText={setText}
        />
        <TouchableOpacity style={styles.addButton} onPress={addTask}>
          <Text style={styles.addButtonText}>Add 💕</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={tasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.taskItem, item.done && styles.taskItemDone]}
            onPress={() => toggleTask(item.id)}
          >
            <View style={styles.checkbox}>
              {item.done && <Text style={styles.checkmark}>✓</Text>}
            </View>
            <Text
              style={[styles.taskText, item.done && styles.taskTextDone]}
            >
              {item.title}
            </Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff5fb", 
    paddingTop: 80,
    paddingHorizontal: 25,
    alignItems: "center",
  },
  header: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#ff9abb",
    marginBottom: 25,
    textShadowColor: "#fff",
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 25,
  },
  input: {
    backgroundColor: "#ffffff",
    borderWidth: 2,
    borderColor: "#ffd6f3",
    borderRadius: 25,
    paddingVertical: 10,
    paddingHorizontal: 15,
    width: 200,
    fontSize: 16,
    color: "#7a6b9b",
    textAlign: "center",
    shadowColor: "#f3c9ff",
    shadowOpacity: 0.4,
    shadowRadius: 4,
    elevation: 2,
  },
  addButton: {
    backgroundColor: "#ffb6c1",
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 25,
    marginLeft: 10,
    shadowColor: "#ffb6c1",
    shadowOpacity: 0.6,
    shadowRadius: 6,
    elevation: 4,
  },
  addButtonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
    textShadowColor: "#ff8fab",
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  taskItem: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fdf2ff",
    borderRadius: 25,
    paddingVertical: 12,
    paddingHorizontal: 15,
    marginVertical: 6,
    width: 280,
    borderWidth: 1.5,
    borderColor: "#ffd9f3",
    shadowColor: "#f1c2ff",
    shadowOpacity: 0.5,
    shadowRadius: 5,
    elevation: 2,
  },
  taskItemDone: {
    backgroundColor: "#e3f7e6",
    borderColor: "#c6f2cd",
  },
  checkbox: {
    width: 25,
    height: 25,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: "#d7b0f3",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 10,
    backgroundColor: "#fff",
  },
  checkmark: {
    fontSize: 16,
    color: "#8e6ccf",
  },
  taskText: {
    fontSize: 16,
    color: "#7a5fa0",
    flexShrink: 1,
  },
  taskTextDone: {
    textDecorationLine: "line-through",
    color: "#9bbf9b",
  },
});
